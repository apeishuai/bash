#!/bin/bash

# download bilibili vedio and convert to image
. bilibili-down.sh
. vedio_2_pic.sh



